Welcome to FHEware
If you use FHEware for the first time
Please run FullyInstall.sh once to install FHEware as root
After installation completed
You can run ./bin/FHEware.sh to start blind extraction
Moreover
FireFox are required
Wish you a pleasure try
